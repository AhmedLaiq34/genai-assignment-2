# Phase 4 handoff: LoRA training and selection

**Operational update (10 November 2026):** for current training steps, commands, Colab/resume details and the corrected local partial-run facts, read [phase_04_training_resume_handoff.md](phase_04_training_resume_handoff.md) first. The local full attempt did save epoch-1 validation metrics; that artifact is diagnostic only, not a selected adapter. The evaluator command below using `--model adapted` is outdated; the implemented flag is `--adapter <path>`.

**Status: blocked on full training; implementation gates passed locally.**

The executable trainer, checkpoint/resume path, real-model smoke, real-model overfit gate and real-model interrupted/resumed rehearsal all passed on 9 November 2026. A full full-precision (FP16) local run on the 6 GiB RTX 3050 laptop GPU did not complete because of GPU memory exhaustion. No validation-selected adapter exists yet, so Phase 4 is **not complete** and no base-versus-adapted quality claim can be made.

## What passed locally

| Gate | Command | Result |
|---|---|---|
| Automated tests | `python -m pytest -q` | 28 passed, 1 PEFT warning |
| Real target smoke | `python scripts/train.py --config configs/train.yaml --run-name phase04_real_smoke --smoke --device cuda` | finite loss 0.5740, grad norm 1.494, 4.07 s/step |
| Real target overfit | 12 training examples, 40 optimizer steps | loss 0.4534 -> 0.1174; exact target matches 1 -> 5 of 12; finite |
| Real resume rehearsal | 4 steps, interrupt at 2 | step/epoch/cursor/order identical; max absolute loss delta 0.0 |
| Partial full run | all 602 usable training rows | reached optimizer step 115; epoch 1 completed at step 76 with diagnostic validation metrics; peak allocated 4,498,746,880 bytes; peak reserved 8,873,050,112 bytes; run not finalized |

Evidence: [local gate report](../results/training/phase04_local_gate.json), [resume report](../results/training/resume_rehearsal.json), [overfit report](../results/training/phase04_real_overfit/overfit_report.json), [smoke summary](../results/training/phase04_real_smoke/export/selected_manifest.json).

## Local blocker

The 6 GiB GPU cannot reliably complete this FP16 training/validation configuration. Windows reported a larger reserved allocation than physical VRAM, and the user reported an out-of-memory failure. The partial run is retained only for diagnosis:

- `checkpoints/phase04_lora_r8/bundles/resume-step-000076-epoch`
- `checkpoints/phase04_lora_r8/bundles/resume-step-000100-periodic`
- `results/training/phase04_lora_r8/`

Do **not** use `results/training/phase04_lora_r8/best_adapter` or `epoch_1/adapter` as the selected Phase 4 artifact. Epoch-1 validation finished and is diagnostic only; the full run did not complete or finalize a selected export.

## Resume on a cloud GPU

Once Colab or Kaggle is available, run from the repository root:

```powershell
python scripts/train.py --config configs/train.yaml --run-name phase04_lora_r8 --device cuda
```

The trainer will use all 602 usable rows, validate after each epoch, checkpoint every 25 steps/300 seconds, and export the validation-selected adapter. After the run, download and verify the export, reload it locally, and run:

```powershell
python scripts/evaluate.py --split validation --config configs/eval.yaml --adapter artifacts/phase04/<run>/selected_adapter --output-dir results/training/<run>/local_validation
```

Do not open the protected test split until Phase 9's frozen manifest is complete and all correctness tests pass.

## What is implemented

- `src/clinical_match/training/data.py`: exact prompt rendering, assistant-only labels, template/EOS validation, patient/example ordering and padding.
- `src/clinical_match/training/trainer.py`: LoRA wrapping, optimizer/scheduler/scaler, deterministic ordering, periodic/epoch checkpoints, epoch validation, selection and export.
- `src/clinical_match/training/checkpoints.py`: verified atomic bundles, RNG/optimizer/scheduler state, resume restoration and pruning.
- `src/clinical_match/training/validation.py`: full 206-row validation generation/scoring.
- `scripts/train.py`: smoke, overfit, resume, stop-after, tiny-model and drive-root options.
- `scripts/rehearse_resume.py`: control vs interrupted/resumed comparison.

## Next phase dependency

Phase 5 is implemented with the unchanged base model as a contract/integration test. Its result objects are adapter-ready, but adapter-specific screening/error evidence must be rerun after Phase 4 completes. Phase 6 base-model cache correctness is independent of the adapter; Phase 8's selected-target speculative run must be repeated after Phase 4.
