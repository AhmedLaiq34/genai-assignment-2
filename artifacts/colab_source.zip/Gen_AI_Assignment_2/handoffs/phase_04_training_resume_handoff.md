# Phase 4 training continuation handoff

**Date:** 10 November 2026  
**Purpose:** hand off the training work to another agent so it can obtain the real validation-selected LoRA adapter, verify it locally, and unblock Phases 5-9.  
**Current state:** Phase 4 code and local plumbing gates are complete. The full FP16 local run did **not** complete. No validation-selected adapter exists yet. Phases 5-8 are implemented against the unchanged base model; adapter-specific reruns are pending.

This document is the operational handoff for the next training agent. Read it before running anything. It supersedes the operational details in `handoffs/phase_04.md` where they differ.

## 1. Immediate objective

On a manually operated Colab GPU, run full LoRA training on the approved 602-row TrialGPT training split, validate after each epoch on the 206-row validation split, select the best checkpoint by validation metrics, export a verified adapter bundle, download it to this laptop, verify its hashes, reload it in a fresh local process, and compare it with the unchanged base model on the same validation split.

Do **not** start Phase 9 final test evaluation. The protected test split stays sealed until the adapter is selected and a complete frozen manifest exists.

## 2. Non-negotiable constraints

1. **Use D: for local work and caches.** Do not fill C: or delete unrelated files. Local cache roots are under `D:\Gen_AI_Assignment_2\.cache\`.
2. **Do not retry full FP16 training on the laptop.** The 6 GiB RTX 3050 Laptop GPU failed with memory exhaustion. Local smoke, overfit, and resume tests already passed; full training belongs on the cloud.
3. **Do not switch to 4-bit/QLoRA silently.** No 4-bit path is implemented in the current trainer. A 4-bit run is a new experiment with different numerical behavior and requires an explicit user/decision-log choice, config support, and a matching evaluation identity.
4. **Use Colab manually through the browser UI.** Do not allocate Colab sessions with the CLI and do not submit Kaggle jobs. If the UI is stuck on allocation for about 15 minutes, stop and record it.
5. **Train only on the 602 approved training rows and validate only on the 206 validation rows.** The test split is 206 rows across 8 patients and is sealed. Do not open it, inspect it, or use it for selection.
6. **Do not change the frozen inference contract during training.** Keep the `v1-provisional` prompt, pinned model revisions, prompt/output budgets, parser, and greedy generation settings. If any of these change, the baseline and adapter comparison must be rebuilt.
7. **Do not call a partial adapter “the trained model.”** A local `best_adapter` directory exists from the failed run but is not a completed Phase 4 artifact.
8. **Do not commit adapter weights or large artifacts to Git.** Keep them under `artifacts/` or another ignored local path.
9. **Run GPU jobs sequentially.** Do not run validation, benchmarking, or both models concurrently on the laptop.
10. **Preserve provenance.** Save source hashes, configs, environment reports, logs, selection evidence, and checksums with every accepted artifact.

## 3. What is already complete

### Phases 0-3

- Environment, model selection, tokenizer checks, data preparation, split manifest, baseline harness, parser, metrics, and unchanged-model baseline are complete.
- Dataset: `ncbi/TrialGPT-Criterion-Annotations`, revision `1cfcafde94a1560a33b4addc1638664fe28fc059`, source SHA-256 `14c547184fac9b013cd17441fd028845b40150c76b022e58334f5494077e5234`.
- Split: 37/8/8 patients, seed 42, 602 train rows, 206 validation rows, 206 test rows. Training annotation `883` is explicitly quarantined because its criterion text is missing.
- Split manifest SHA-256: `309ea164a836f9a3f6d6c315578be990370971990412bbb75ef77cde707e063b`.
- Target: `Qwen/Qwen2.5-1.5B-Instruct`, revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`.
- Draft: `Qwen/Qwen2.5-0.5B-Instruct`, revision `7ae557604adf67be50417f59c2c2f167def9a775`.
- Baseline validation metrics (`results/baseline/base_greedy_v1_validation/metrics.json`):
  - accuracy `0.13106796116504854`
  - classification macro-F1 `0.12405091068685538`
  - evidence micro-F1 `0.15492957746478872`
  - 4 invalid predictions
  - generation backend `transformers_generate_greedy_cache`
  - 206/206 validation rows, test not opened
- Baseline was produced on the local RTX 3050 with FP16. Use the local baseline for the fair local before/after comparison.

### Phase 4 implementation and local gates

Implemented files:

- `src/clinical_match/training/data.py`: exact prompt rendering, assistant-only labels, template/EOS validation, deterministic epoch order, padding.
- `src/clinical_match/training/trainer.py`: LoRA wrapping, AdamW/scheduler/scaler, gradient accumulation, gradient checkpointing, validation, selection, checkpointing, export.
- `src/clinical_match/training/checkpoints.py`: verified bundles, optimizer/scheduler/scaler/RNG state, resume restoration, Drive publishing, pruning.
- `src/clinical_match/training/validation.py`: full 206-row validation generation and scoring.
- `scripts/train.py`: training entry point, smoke/overfit/resume/stop options.
- `scripts/rehearse_resume.py`: uninterrupted control versus interrupted/resumed comparison.
- `scripts/evaluate.py`: base or adapter evaluation on train/validation only; refuses test.
- `notebooks/colab_runner.ipynb`: current thin Colab launcher for environment, data, tests, pilots, overfit/rehearsal, full training, export, and download packaging.
- `docs/colab_manual_setup.md`: manual Colab workflow.

Local evidence that passed:

| Gate | Evidence | Result |
|---|---|---|
| Automated tests | current full suite | 75 passed, 1 warning, 111 subtests passed |
| Real target smoke | `results/training/phase04_real_smoke/` | finite loss `0.5740`, grad norm `1.494`, ~4.07 s/step |
| Real target overfit | `results/training/phase04_real_overfit/overfit_report.json` | 12 examples, 40 steps, loss `0.4534 -> 0.1174`, exact target matches `1 -> 5`, finite |
| Real resume rehearsal | `results/training/resume_rehearsal.json` | step/epoch/cursor/order identical; max loss delta `0.0` |
| Full local attempt | `results/training/phase04_local_gate.json` | blocked: OOM; not accepted |

The trainer has not been changed since these local tests except for unrelated downstream Phase 7/8 work. Re-run the suite before a new training run.

### Phases 5-8 status

- Phase 5 screening service and evidence/error pipeline are implemented and locally tested against the base model. The development error ledger is base-model evidence only and must be regenerated with the adapter.
- Phase 6 explicit cached/uncached decoding is implemented and exactly token-equivalent on the base model. Its scripts currently load the base model only; adapter support must be added for an adapter rerun.
- Phase 7 tiled attention is standalone and adapter-independent. It is an educational comparison, not integrated into the Qwen model.
- Phase 8 deterministic greedy speculative decoding is implemented and exactly token-equivalent on the base model. Its scripts currently load the base target only; adapter support must be added for an adapter rerun.
- Phase 9 is blocked until the selected adapter and frozen manifest exist.

## 4. Training contract

Current `configs/train.yaml`:

- LoRA rank `8`, alpha `16`, dropout `0.05`, target modules `q_proj` and `v_proj`.
- AdamW, learning rate `2e-4`, weight decay `0.01`, betas `[0.9, 0.999]`.
- Linear schedule, warmup ratio `0.05`, gradient norm cap `1.0`.
- Microbatch `1`, gradient accumulation `8`, maximum `3` epochs, seed `42`.
- FP16, SDPA attention, gradient checkpointing, training KV cache off.
- `max_total_tokens=1024`, `max_new_tokens=96`, `max_seq_len=1024`.
- Validation after each epoch, same prompt/parser/greedy settings as the baseline.
- Checkpoint every 25 optimizer steps or 300 seconds, plus every epoch; keep two recent resume bundles.
- Selection: classification macro-F1, then evidence micro-F1, then lower validation loss.
- Export: `best_adapter` copied to `selected_adapter`, plus `selected_manifest.json`, configs, environment, data hashes, history, log, and a verified export bundle.

Step arithmetic with 602 examples and accumulation 8:

- `ceil(602 / 8) = 76` optimizer steps per epoch.
- 3 epochs = 228 planned optimizer steps.
- Warmup = `int(228 * 0.05) = 11` steps.
- At the local measured ~3.7 s/step, training is about 5 minutes per epoch; full 206-row validation was about 6 minutes locally. Budget roughly 30-45 minutes for the full run on a comparable GPU, but measure on the actual Colab GPU and do not rely on this estimate.

### Important implementation behavior

- Only assistant answer tokens are supervised; prompt and padding labels are `-100`.
- The assistant answer includes the template end-of-turn token.
- Training data order is deterministic per epoch: `random.Random(seed + epoch).shuffle`.
- Checkpoints include adapter, optimizer, scheduler, scaler, Python/NumPy/PyTorch RNG, epoch/global step, example cursor, data order, resolved config, environment, and input hashes.
- `resolve_resume_dir` verifies a bundle and restores it before resuming.
- `publish_bundle` refuses to overwrite an existing Drive bundle of the same name. Use a unique run name on a fresh cloud run.
- The trainer validates after each epoch and writes `epoch_N/validation/metrics.json`.
- The final export only exists after the run finalizes. A process that dies after a checkpoint does not produce `export/`.
- If validation is skipped, `_finalize` falls back to `last_state_no_validation_selection`; this is **not** a valid Phase 4 selection and must not be accepted.

## 5. Existing local partial run: read this before touching artifacts

`results/training/phase04_lora_r8/` contains diagnostic evidence from the failed local run. It is **not** the selected adapter.

Facts:

- The run reached optimizer step 115, which is mid-epoch 2.
- Epoch 1 completed at step 76 and validation metrics **do** exist:
  - `results/training/phase04_lora_r8/epoch_1/validation/metrics.json`
  - accuracy `0.7184466019417476`
  - macro-F1 `0.3457388939998816`
  - evidence micro-F1 `0.27993779160186627`
  - validation loss `0.15450268192668853`
  - adapter hash `56411c794a94efebcbfa4a413b44b7f35854db77d731697625f8bea06b0f217a`
- An earlier version of `handoffs/phase_04.md` said no epoch-1 metrics were saved. That was incorrect; the metrics file exists and the old handoff has been corrected.
- `best_adapter/` is a copy of that epoch-1 adapter and is not a finished run selection.
- The local run log contains duplicated step 77-115 records from a retry; do not treat it as a clean resume lineage.
- Peak allocated memory was `4,498,746,880` bytes (about `4.19 GiB`); peak reserved was `8,873,050,112` bytes (about `8.26 GiB`) on a 6 GiB GPU. The run ended in OOM.
- Do not use `phase04_lora_r8/best_adapter`, `epoch_1/adapter`, or the local partial checkpoints as the Phase 4 deliverable.
- Do not resume the local partial run on Colab unless the user explicitly requests a cross-device resumed experiment. A clean cloud run is the default and gives a complete 3-epoch history and unambiguous selection evidence.

## 6. Pre-flight on the laptop

Run from `D:\Gen_AI_Assignment_2`.

1. Inspect the working tree and preserve all current changes. Do not use `git clean`, `git reset --hard`, or delete checkpoints/artifacts.
2. Run the full test suite:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

Expected: 75 passed, 1 PEFT warning, 111 subtests passed. If this changes, understand why before training.

3. Rebuild the source archive after any documentation/code changes:

```powershell
.\.venv\Scripts\python.exe scripts\package_colab_source.py
```

This writes `artifacts\colab_source.zip` and `artifacts\colab_source.zip.sha256`. The archive is source-only: it does not include prepared JSONL, raw Parquet, model weights, or caches.

4. Copy **both** the ZIP and sidecar to Google Drive:

```text
MyDrive/GenAI_Assignment_2_source/colab_source.zip
MyDrive/GenAI_Assignment_2_source/colab_source.zip.sha256
```

5. Upload or open `notebooks/colab_runner.ipynb` in Colab. Do not paste credentials into notebook source, logs, Git, or chat.

Optional local check that the source zip is current and contains the training handoff:

```powershell
$env:PYTHONIOENCODING='utf-8'
& .venv\Scripts\python.exe -c "import zipfile; z=zipfile.ZipFile(r'artifacts\colab_source.zip'); print([n for n in z.namelist() if 'phase_04_training_resume_handoff.md' in n])"
Get-Content artifacts\colab_source.zip.sha256
```

## 7. Cloud session: start and verify

1. Open the notebook in the Colab UI, signed into the Google account that owns the Drive folder.
2. **Runtime > Change runtime type > GPU** if an accelerator is offered, then connect. A T4 is not guaranteed.
3. Run cells 1-5 in order. They:
   - mount Drive after user authorization;
   - verify the source ZIP against its sidecar;
   - extract a hash-versioned source copy;
   - copy the active source to `/content`;
   - set Hugging Face cache to `/content/.cache/huggingface`;
   - run `scripts/doctor.py`;
   - install `requirements-colab.txt` and `requirements-dev.txt` without replacing Colab's PyTorch;
   - run tokenizer checks, regenerate/verify the pinned data, and run the full test suite.
4. Read the environment report before training. Require `cuda_available=true` and record the actual GPU name, VRAM, RAM, disk, Python, PyTorch, Transformers, and PEFT versions. If CUDA is unavailable, stop; do not train on CPU.
5. `scripts/verify_colab_handoff.py` downloads the pinned Parquet snapshot and regenerates the data because the source archive excludes data files. It verifies the manifest hash. If the download hash fails, stop; do not substitute local data or an unpinned dataset version.
6. Confirm the target model downloads to `/content/.cache/huggingface`. Expect the 1.5B target plus tokenizer; allow time and check free disk. Do not put model weights on Drive unless the user explicitly asks.

If the runtime disconnects, the `/content` source, cache, and checkpoints disappear. Only Drive artifacts survive.

## 8. Pre-training gates in Colab

Run the notebook gates in this order. Do not start full training if either fails.

1. Real-model overfit smoke (cell 11):
   - 12 examples, 40 steps.
   - Requires finite losses, a downward loss trend, and at least as many exact target matches after as before.
   - Expected local precedent: `0.4534 -> 0.1174`, matches `1 -> 5`.
2. Interrupted/resumed rehearsal (cell 12):
   - 4 steps, interrupt at 2.
   - Requires matching global step, epoch, example cursor, order, loss count, finite losses, and max absolute loss delta `<= 0.01`.
   - Local precedent: delta `0.0`.

Write down the exact commands and results. These gates prove the train path works; they do not select an adapter.

## 9. Full cloud training

### 9.1 Choose a run name

Use a unique, recorded run name. The notebook uses `phase04_lora_<RUN_ID>`, where `RUN_ID` is a UTC timestamp. Record the actual run name immediately; a lost kernel will create a new `RUN_ID` if cells are rerun from the top.

Recommended explicit name for a clean run:

```text
phase04_lora_r8_colab_20261110
```

Replace the date/suffix with the actual date and keep it unique. Do not reuse a run name whose Drive folder already contains same-step bundles.

### 9.2 Start the full run

The notebook cell 14 invokes:

```bash
python scripts/train.py \
  --run-name "phase04_lora_r8_colab_20261110" \
  --drive-dir /content/drive/MyDrive/GenAI_Assignment_2_checkpoints
```

If using the notebook as written, it supplies a timestamped `--run-name`; record that exact string. The trainer reads `configs/train.yaml` by default and runs 3 epochs with validation and checkpoints.

Expected cloud artifacts:

```text
/content/Gen_AI_Assignment_2_<sourcehash>/checkpoints/<run_name>/
  bundles/resume-step-XXXXXX-epoch/
  bundles/resume-step-XXXXXX-periodic/
  exports/phase04-export-<run_name>-<timestamp>/
  latest.json

/content/drive/MyDrive/Gen_AI_Assignment_2_checkpoints/
  checkpoints/<run_name>/resume-step-XXXXXX-epoch/
  checkpoints/<run_name>/resume-step-XXXXXX-periodic/
  exports/<run_name>/phase04-export-<run_name>-<timestamp>/
```

Each bundle must have `COMPLETE.json` and `bundle_manifest.json`. The Drive copy is verified immediately after publishing.

### 9.3 Monitor

Check the printed step records:

```text
step=<n> epoch=<epoch> loss=<loss> lr=<lr> grad=<norm> sec=<seconds>
```

Also inspect `results/training/<run_name>/train_log.jsonl` and `epoch_N/validation/metrics.json` after each epoch. Do not kill the runtime during validation or checkpoint writing.

### 9.4 Resume after a disconnect

Reconnect, rerun cells 2-5 to restore the environment and source, then reuse the **original** run name and resume from the newest verified Drive bundle:

```bash
RUN_NAME="phase04_lora_r8_colab_20261110"
BUNDLE_ROOT="/content/drive/MyDrive/GenAI_Assignment_2_checkpoints/checkpoints/${RUN_NAME}"
RESUME=$(ls -dt "${BUNDLE_ROOT}"/resume-step-* | head -1)

python scripts/train.py \
  --config configs/train.yaml \
  --run-name "${RUN_NAME}" \
  --device cuda \
  --drive-dir /content/drive/MyDrive/GenAI_Assignment_2_checkpoints \
  --resume "${RESUME}"
```

Do not resume from a partial local bundle unless the user explicitly chooses that experiment. Do not change hyperparameters, run name, source identity, or precision when resuming; the trainer rejects identity mismatches.

### 9.5 Failure policy

- If Colab has no GPU or the runtime cannot start, stop after the time-box and continue local adapter-independent work. Do not repeatedly queue sessions.
- If cloud training OOMs, record GPU/VRAM, config, step, tensor lengths, peak allocated/reserved, and the failing operation. Do not silently lower precision, quantization, sequence length, or model. Any such change needs a new documented experiment and matching evaluation identity.
- If training is killed after an epoch but before finalize, the run is incomplete until resumed to finalize and export.
- If a checkpoint or Drive copy fails verification, stop. Do not use it.

## 10. Verify and download the export

After training finalizes, run notebook cell 16. It verifies the export bundle, restores it to a fresh directory, compares bundle inventories, creates `phase04-<RUN_ID>.zip`, and writes a `.sha256` sidecar in `MyDrive/GenAI_Assignment_2_source/`.

Download both files to:

```text
D:\Gen_AI_Assignment_2\artifacts\phase04\
```

Do this before ending the Colab runtime. Notebook output alone is not an artifact.

On the laptop, verify the transfer:

```powershell
$zip = "D:\Gen_AI_Assignment_2\artifacts\phase04\phase04-<RUN_ID>.zip"
Get-FileHash -Algorithm SHA256 -LiteralPath $zip
Get-Content "D:\Gen_AI_Assignment_2\artifacts\phase04\phase04-<RUN_ID>.zip.sha256"
```

Extract to a new directory that does not exist yet:

```powershell
$dest = "D:\Gen_AI_Assignment_2\artifacts\phase04\<RUN_NAME>"
Expand-Archive -LiteralPath $zip -DestinationPath $dest
```

Because the Colab archive is made from the bundle root, the extracted folder itself should contain `COMPLETE.json`, `bundle_manifest.json`, `selected_adapter/`, `selected_manifest.json`, and the exported logs/configs. Verify the bundle:

```powershell
$env:PYTHONIOENCODING='utf-8'
& .\.venv\Scripts\python.exe -c "from pathlib import Path; from src.clinical_match.checkpointing import verify_bundle; import json; b=Path(r'artifacts\phase04\<RUN_NAME>'); m=verify_bundle(b); print(m['bundle_name'], len(m['files']))"
```

Inspect the selection manifest before evaluating:

```powershell
$env:PYTHONIOENCODING='utf-8'
& .\.venv\Scripts\python.exe -c "import json; from pathlib import Path; p=Path(r'artifacts\phase04\<RUN_NAME>/selected_manifest.json'); m=json.loads(p.read_text()); print(json.dumps({k:m.get(k) for k in ['run_name','selection_source','selected','global_step','epochs_completed','model_id','model_revision','prompt_revision','selected_adapter_sha256']}, indent=2))"
```

Acceptance requirements:

- `selection_source == "best_validation"`, not `last_state_no_validation_selection`.
- `selected` is present and names an epoch.
- `selected_adapter_sha256` matches the extracted `selected_adapter/`.
- `epochs_completed == 3` for the canonical run, or an explicitly documented reason for stopping earlier.
- The manifest identifies the pinned target, prompt revision, data hashes, and environment.
- All bundle files verify.
- The local adapter loads in a fresh process.

If `selection_source` is `last_state_no_validation_selection`, stop. That artifact is not a valid Phase 4 selection.

## 11. Local adapter reload and fair comparison

The current `scripts/evaluate.py` uses `--adapter`, not the older `--model adapted` form.

Run the full 206-row validation evaluation with the local pinned base model plus the extracted adapter:

```powershell
$env:HF_HOME='D:\Gen_AI_Assignment_2\.cache\huggingface'
$env:HUGGINGFACE_HUB_CACHE='D:\Gen_AI_Assignment_2\.cache\huggingface\hub'
$env:HF_HUB_OFFLINE='1'
$env:TRANSFORMERS_OFFLINE='1'
$env:TEMP='D:\Gen_AI_Assignment_2\.cache\tmp'
$env:TMP='D:\Gen_AI_Assignment_2\.cache\tmp'
$env:PYTHONIOENCODING='utf-8'

& .\.venv\Scripts\python.exe scripts\evaluate.py `
  --config configs/eval.yaml `
  --split validation `
  --adapter "artifacts\phase04\<RUN_NAME>\selected_adapter" `
  --output-dir "results/training/<RUN_NAME>/local_validation"
```

This writes:

```text
results/training/<RUN_NAME>/local_validation/
  validation_predictions.jsonl
  metrics.json
  run_config.json
```

Use the local run for the fair deployment comparison because the Phase 3 baseline was produced on the same local RTX 3050 with the same prompt and generation backend. Do not compare a cloud adapter metric to a local base metric and call the difference a speed or quality result. Keep cloud selection metrics and local reload metrics separate.

Compare these fields with `results/baseline/base_greedy_v1_validation/metrics.json`:

| Field | Base | Adapter | Delta |
|---|---:|---:|---:|
| classification accuracy | 0.1311 | record | record |
| classification macro-F1 | 0.1241 | record | record |
| evidence micro-F1 | 0.1549 | record | record |
| invalid predictions | 4 | record | record |
| parse failures | record | record | record |
| output-cap truncations | 0 | record | record |

Also check:

- `scope.split == "validation"`, `scope.n == 206`, `scope.test_data_opened == false`.
- `artifacts.adapter_sha256` matches the selected adapter hash.
- `artifacts.prompt_config_sha256`, `split_manifest_sha256`, `input_jsonl_sha256`, and model revision match the baseline.
- Predictions are scored from all 206 rows; no filtering of hard cases.
- A regression is a valid result. Do not hide it or substitute the base model.

If local reload produces category/parse behavior that differs materially from the cloud validation metrics, investigate before proceeding. Exact token sequences can differ across devices; parsed-output and metric drift must be explained. Never reselect the epoch using test data.

## 12. When training is accepted

A Phase 4 acceptance record must include:

- Full training command, run name, actual Colab GPU/session, start/end time, and software versions.
- Complete logs and `training_history.json`.
- Per-epoch validation metrics and selected epoch.
- Verified resume bundles and evidence that at least one checkpoint was published and restored.
- Export bundle and SHA-256.
- Download transfer hash.
- Local fresh-process adapter reload command and result.
- Base-versus-adapter validation comparison with absolute metrics and deltas.
- Explicit statement that the test split was not opened.
- Updated `handoffs/phase_04.md`, `research/decision_log.md`, and `output/deliverables_checklist.md`.

Recommended canonical local adapter location after verification:

```text
D:\Gen_AI_Assignment_2\artifacts\adapters\phase04\<run_name>\
  selected_adapter/
  selected_manifest.json
  metrics.json
  environment.json
  SHA256SUMS.txt
```

Keep the original downloaded bundle unchanged as the provenance copy. Do not commit adapter weights.

## 13. Downstream work after the adapter exists

Do not start these until Phase 4 is accepted.

1. **Phase 5:** rerun screening and rebuild `results/errors/development.md` with the adapter. Use `scripts/screen_example.py --adapter <path>` and preserve the same policy/schema. The old error ledger is base-model evidence only.
2. **Phase 6:** add adapter support to `scripts/check_decoding_correctness.py` and `scripts/benchmark_decoding.py`; they currently call `load_eval_model(cfg, device)` without an adapter. Rerun exact cached/uncached equality and benchmarks. Do not change the decoder contract.
3. **Phase 7:** attention is adapter-independent. No adapter rerun is required; keep it standalone and continue to report the honest slowdown.
4. **Phase 8:** add adapter support to the target load in `scripts/check_speculative_correctness.py` and `scripts/benchmark_speculative.py`; the draft remains the pinned 0.5B model. Rerun correctness and the k sweep with the selected target adapter. Keep draft/target tokenizer compatibility checks.
5. **Phase 9:** only after the adapter, all correctness tests, and the frozen manifest exist. Do not open the sealed test split before that point.

## 14. Known traps and stale documentation

- An earlier revision of `handoffs/phase_04.md` said no epoch-1 validation metrics were saved. The metrics exist and are diagnostic only; the current file is corrected.
- Older notes use `--model adapted`; the implemented evaluator uses `--adapter <path>`.
- `output/phase_4_6_implementation_plan.md` and parts of `output/master_plan.md` still say the notebook does not train on TrialGPT. The current notebook and `scripts/train.py` do. Treat this handoff and the code as current.
- The local `phase04_lora_r8/best_adapter` is not a final selection.
- The notebook uses a timestamped run name. If the kernel dies, rerunning from the top creates a new name; record the name or use an explicit fixed name before the full run.
- The source archive excludes prepared JSONL and raw Parquet. Colab must regenerate data from the pinned source; do not bypass its hash checks.
- Colab `/content` is ephemeral. Drive bundles survive; notebook output does not.
- `publish_bundle` refuses to overwrite a same-name Drive bundle. Use a unique run name or resume the original run.
- `scripts/evaluate.py` intentionally rejects any split other than `train` or `validation`.
- The local `train_log.jsonl` contains duplicated step 77-115 records from a retry; do not use it as a clean resume sequence.
- The local partial run peaked at `4,498,746,880` bytes allocated (about `4.19 GiB`) and `8,873,050,112` bytes reserved (about `8.26 GiB`) on a 6 GiB GPU. The cloud run should be monitored, but do not copy the local OOM workaround into config without documenting it.
- `best_adapter`/`selected_adapter` are PEFT adapter directories, not full model weights. Always load with the pinned base model revision.
- Do not use `--skip-validation` for the accepted full run.

## 15. Quick checklist for the training agent

- [ ] Full local test suite passes.
- [ ] Source ZIP rebuilt and sidecar copied to Drive.
- [ ] Notebook uploaded/opened; GPU verified; actual environment recorded.
- [ ] Data regenerated and manifest hash verified.
- [ ] Real overfit gate passes.
- [ ] Interrupted/resumed rehearsal passes.
- [ ] Unique run name recorded.
- [ ] Full 3-epoch run finalizes and validation metrics exist for each completed epoch.
- [ ] Selection is `best_validation`; selected epoch and metrics are recorded.
- [ ] Verified export bundle exists on Drive and downloaded to `artifacts/phase04/`.
- [ ] ZIP SHA-256 and bundle inventory verified locally.
- [ ] Adapter reloads in a fresh local process.
- [ ] Local base-versus-adapter validation comparison saved.
- [ ] Test split remains unopened.
- [ ] Phase 4 handoff, decision log, and checklist updated.
