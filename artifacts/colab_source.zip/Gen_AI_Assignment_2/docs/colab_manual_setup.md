# Manual Google Colab workflow

**Current choice:** use Colab through its browser interface. The user will allocate and operate the runtime manually. Do not submit notebooks with a CLI. Kaggle remains a historical fallback record; its jobs are not part of the active workflow.

Colab does not guarantee a particular accelerator or continuous availability. Google documents GPU selection under **Runtime > Change runtime type**; free GPU access and resource limits can vary. Check the actual session before spending time on downloads or training. [Colab GPU guidance](https://colab.research.google.com/notebooks/pro.ipynb), [Colab resource limits](https://research.google.com/colaboratory/intl/en/faq.html).

## Prepare the files on the laptop

From the repository root, rebuild a fresh source bundle so it contains the current scripts and docs:

```powershell
.\.venv\Scripts\python.exe scripts\package_colab_source.py
```

The command creates `artifacts/colab_source.zip` and `artifacts/colab_source.zip.sha256`. Upload both to the Google Drive folder `MyDrive/GenAI_Assignment_2_source/`. Upload `notebooks/colab_runner.ipynb` to Drive or open it in Colab using **File > Upload notebook**. Never put credentials in the notebook or source archive.

## Start a session manually

1. Open the notebook in Colab while signed into the Google account that owns the Drive folder.
2. Choose **Runtime > Change runtime type**, select a GPU accelerator if one is offered, then connect. A T4 is not guaranteed.
3. Run the first code cell. It asks for Drive access, checks the ZIP against its SHA-256 sidecar, and extracts a versioned source copy. Grant access only after confirming the notebook is this project's `colab_runner.ipynb`.
4. Run the next code cell. It copies the checked source into `/content`, sets the Hugging Face cache there, and records the actual runtime. Inspect the report for `cuda_available`, GPU name, VRAM, RAM, PyTorch and free disk. If CUDA is false, stop before the GPU-dependent cells.
5. Continue the notebook cells in order. The dependency cell keeps Colab's existing PyTorch build and installs the project's pinned shared packages. If it asks for a runtime restart, restart and rerun cells from the top.
6. The verification cells check tokenizer compatibility, regenerate/verify the canonical split, run the repository test suite, and then run the inference and synthetic LoRA fit pilots.
7. Phase 4 cells then run a small real-model overfit smoke, an interrupted/resumed rehearsal, and the full TrialGPT LoRA run. The full run writes verified resume bundles and the selected export to `MyDrive/GenAI_Assignment_2_checkpoints/<run>/`. If the runtime disconnects, restart and resume from the newest `resume-step-*` bundle instead of restarting from step zero.
8. The last two cells verify the export, restore it into a fresh directory, and write `phase04-<timestamp>.zip` plus `.sha256` to Drive. Download the zip to `D:\Gen_AI_Assignment_2\artifacts\phase04\`, verify its hashes, and run the local adapter comparison before ending the session.

Colab documents manual Drive authorization because notebook code can access mounted Drive files; review the requested access before approving it. Runtime storage is temporary, and Drive operations can encounter quota limits. Save verified bundles regularly; do not treat notebook output as a checkpoint. [Drive authorization and limits](https://research.google.com/colaboratory/intl/en/faq.html).

## Current implementation boundary

The notebook supports environment checks, Phase 2 verification, tokenizer/model feasibility checks, the synthetic LoRA pilot, real-model Phase 4 training/resume rehearsals, full LoRA training, validation selection, and verified export to Drive. Phase 4 is not complete until the exported adapter is downloaded, hash-verified, and locally compared against the unchanged base model on the same 206 validation rows.

If the Colab UI again remains on allocation for about 15 minutes, stop that attempt, record the date and screen text, and continue local non-training implementation. Do not repeatedly queue sessions or switch services without recording a new decision.
