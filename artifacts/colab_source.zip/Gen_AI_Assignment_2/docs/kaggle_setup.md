# Archived: Kaggle research attempt

This page records the temporary Kaggle route considered on 9 November 2026. **It is not an active setup guide.** The current decision is to use Google Colab manually through the browser. Follow [manual Colab setup](colab_manual_setup.md).

Kaggle CLI authentication and a quota query succeeded. A private GPU probe completed but reported a CPU-only PyTorch build with CUDA unavailable; a revised probe and a CPU Phase 2 verification job stayed queued while the user-reported site banner described a notebook startup/connectivity issue. No Kaggle model-training result exists. The historical submission records remain in `results/kaggle_gpu_probe_v1.json`, `results/kaggle_phase02_submission.json` and `results/kaggle_resubmission_status.json`.

Do not resubmit or use the old Kaggle job builders unless the user changes the compute decision. The active manual workflow and Colab runner are documented in [`docs/colab_manual_setup.md`](colab_manual_setup.md) and [`notebooks/colab_runner.ipynb`](../notebooks/colab_runner.ipynb).
